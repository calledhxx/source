// Mione external library: system
// Provides access to the outside world (console, files, external programs); called with `enter` from Module/system/system.mio.
//
// Build (in an x64 Developer Command Prompt, from this folder):
//   cl /nologo /LD /O2 /utf-8 /I "D:\MioneClaude\Mione" system.c /Fe:system.dll
//
// The library exchanges data with the interpreter through the ValueObj / ExternalLibrary structures in OBJECTS.h, so both must be built with the same OBJECTS.h.
// Returned strings and arrays are allocated by this library's CRT; the interpreter only reads them and never frees them.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>

#include "OBJECTS.h"

#define EXPORT __declspec(dllexport)

static ExternalLibraryRespondObj Fail(const ExternalLibraryRequestObj Request, char * Message)
{
    ExternalLibraryRespondObj Result = {0};

    Result.Event = Request.EventTemplate;
    Result.Event.Code = EVENT_RUNTIME_ERROR;
    Result.Event.Message = Message;

    return Result;
}

static ValueObj * NewValues(const unsigned Count)
{
    ValueObj * Values = calloc(Count, sizeof(ValueObj));

    if (!Values)
    {
        fputs("system: out of memory\n", stderr);
        exit(EXIT_FAILURE);
    }

    return Values;
}

static ValueObj StringValue(char * Text)
{
    return (ValueObj){.ValueType = VALUE_STRING_TYPE, .String = Text};
}

static const ValueObj * Argument(const ExternalLibraryRequestObj Request, const unsigned Index)
{
    static const ValueObj Null = {0};

    return Index < Request.ValueCarrier.CarrierLen ? &Request.ValueCarrier.Carrier[Index] : &Null;
}

//////////////////////////////////////// print ////////////////////////////////////////
// print(values...): prints all values separated by spaces, followed by a line break.

EXPORT ExternalLibraryRespondObj print(const ExternalLibraryRequestObj Request)
{
    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;

    for (unsigned Index = 0; Index < Request.ValueCarrier.CarrierLen; Index++)
    {
        const ValueObj Value = Request.ValueCarrier.Carrier[Index];

        if (Index)
            fputc(' ', stdout);

        switch (Value.ValueType)
        {
        case VALUE_STRING_TYPE: fputs(Value.String, stdout); break;
        case VALUE_NUMBER_TYPE: printf("%.14g", Value.Number); break;
        case VALUE_DB_TYPE: fputs(Value.db ? "true" : "false", stdout); break;
        case 0: fputs("null", stdout); break;
        case VALUE_TABLE_TYPE: fputs("<table>", stdout); break;
        case VALUE_FUNCTION_TYPE: fputs("<function>", stdout); break;
        case VALUE_RANGE_TYPE: fputs("<range>", stdout); break;
        default: fputs("<library>", stdout); break;
        }
    }

    fputc('\n', stdout);
    fflush(stdout);

    return Result;
}

//////////////////////////////////////// input ////////////////////////////////////////
// input(): reads one line (without the line break); returns null at end of file.

EXPORT ExternalLibraryRespondObj input(const ExternalLibraryRequestObj Request)
{
    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;

    size_t Length = 0, Capacity = 128;
    char * Line = malloc(Capacity);
    int Char;

    while ((Char = fgetc(stdin)) != EOF && Char != '\n')
    {
        if (Length + 1 >= Capacity)
            Line = realloc(Line, Capacity *= 2);

        Line[Length++] = (char)Char;
    }

    if (Char == EOF && !Length)
    {
        free(Line);
        return Result;
    }

    if (Length && Line[Length - 1] == '\r')
        Length--;

    Line[Length] = 0;

    Result.ValueCarrier.CarrierLen = 1;
    Result.ValueCarrier.Carrier = NewValues(1);
    Result.ValueCarrier.Carrier[0] = StringValue(Line);

    return Result;
}

//////////////////////////////////////// read ////////////////////////////////////////
// read(path): reads the whole file in binary mode as a string; returns null if the file does not exist.

EXPORT ExternalLibraryRespondObj read(const ExternalLibraryRequestObj Request)
{
    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;

    const ValueObj * Path = Argument(Request, 0);

    if (Path->ValueType != VALUE_STRING_TYPE)
        return Fail(Request, "read(path): path should be a string.");

    FILE * File = fopen(Path->String, "rb");

    if (!File)
        return Result;

    size_t Length = 0, Capacity = 4096;
    char * Content = malloc(Capacity);
    size_t Read;

    while ((Read = fread(Content + Length, 1, Capacity - Length - 1, File)) > 0)
    {
        Length += Read;

        if (Length + 1 >= Capacity)
            Content = realloc(Content, Capacity *= 2);
    }

    fclose(File);

    Content[Length] = 0;

    Result.ValueCarrier.CarrierLen = 1;
    Result.ValueCarrier.Carrier = NewValues(1);
    Result.ValueCarrier.Carrier[0] = StringValue(Content);

    return Result;
}

//////////////////////////////////////// write ////////////////////////////////////////
// write(path, text): writes the string to the file unchanged in binary mode (overwriting it) and returns whether it succeeded.

EXPORT ExternalLibraryRespondObj write(const ExternalLibraryRequestObj Request)
{
    static ValueObj Answer[1];

    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;

    const ValueObj * Path = Argument(Request, 0);
    const ValueObj * Content = Argument(Request, 1);

    if (Path->ValueType != VALUE_STRING_TYPE || Content->ValueType != VALUE_STRING_TYPE)
        return Fail(Request, "write(path, text): path and text should be strings.");

    FILE * File = fopen(Path->String, "wb");
    int Success = 0;

    if (File)
    {
        const size_t Length = strlen(Content->String);
        Success = fwrite(Content->String, 1, Length, File) == Length;
        Success = fclose(File) == 0 && Success;
    }

    Answer[0] = (ValueObj){.ValueType = VALUE_DB_TYPE, .db = (char)Success};

    Result.ValueCarrier.CarrierLen = 1;
    Result.ValueCarrier.Carrier = Answer; //The interpreter only reads the result, so a static array can be reused

    return Result;
}

//////////////////////////////////////// run ////////////////////////////////////////
// run(command, working directory, standard input, time limit in ms, memory limit in bytes, CPU time limit in ms)
//   -> standard output, exit code, standard error, timed out, memory limit exceeded, peak memory usage (bytes), CPU time (ms)
//   "Timed out" is true when either the elapsed time limit or the CPU time limit was exceeded.
//   The time limit applies to elapsed time. The CPU time excludes waiting (e.g. antivirus scans of new files or waiting for input), which makes it suitable for TLE decisions.
//   The command runs through `cmd.exe /S /C`, so tools on the PATH such as gcc and cl can be used.
//   The working directory, standard input and all limits may be null. On timeout the whole process tree is terminated through a Job and the exit code is -1.
//   The memory limit applies to every process in the tree (the Job's ProcessMemoryLimit): allocations beyond it fail,
//   and the Job's notifications are used to report whether the memory limit was exceeded.
//   "\r\n" in the captured output is normalized to "\n".

typedef struct
{
    HANDLE Handle;
    char * Text;
    size_t Length;
    size_t Capacity;
} PipeBuffer;

static DWORD WINAPI ReadPipeThread(LPVOID Parameter)
{
    PipeBuffer * Buffer = Parameter;

    for (;;)
    {
        if (Buffer->Length + 4096 + 1 > Buffer->Capacity)
        {
            Buffer->Capacity = Buffer->Capacity ? Buffer->Capacity * 2 : 8192;
            Buffer->Text = realloc(Buffer->Text, Buffer->Capacity);

            if (!Buffer->Text)
                return 1;
        }

        DWORD Read = 0;

        if (!ReadFile(Buffer->Handle, Buffer->Text + Buffer->Length, 4096, &Read, NULL) || !Read)
            break;

        Buffer->Length += Read;
    }

    return 0;
}

typedef struct
{
    HANDLE Handle;
    const char * Text;
} PipeInput;

static DWORD WINAPI WritePipeThread(LPVOID Parameter)
{
    PipeInput * Input = Parameter;
    size_t Remain = Input->Text ? strlen(Input->Text) : 0;
    const char * Cursor = Input->Text;

    while (Remain)
    {
        DWORD Written = 0;

        if (!WriteFile(Input->Handle, Cursor, Remain > 65536 ? 65536 : (DWORD)Remain, &Written, NULL) || !Written)
            break;

        Cursor += Written;
        Remain -= Written;
    }

    CloseHandle(Input->Handle); //Let the child process read EOF

    return 0;
}

//Converts "\r\n" to "\n" and returns a newly allocated string
static char * TakeOutput(const PipeBuffer * Buffer)
{
    char * Text = malloc(Buffer->Length + 1);
    size_t Length = 0;

    for (size_t Index = 0; Index < Buffer->Length; Index++)
    {
        if (Buffer->Text[Index] == '\r' && Index + 1 < Buffer->Length && Buffer->Text[Index + 1] == '\n')
            continue;

        Text[Length++] = Buffer->Text[Index];
    }

    Text[Length] = 0;

    return Text;
}

static int CreateChildPipe(HANDLE * ParentEnd, HANDLE * ChildEnd, const int ChildReads)
{
    SECURITY_ATTRIBUTES Attributes = {sizeof(SECURITY_ATTRIBUTES), NULL, TRUE};
    HANDLE Read, Write;

    if (!CreatePipe(&Read, &Write, &Attributes, 0))
        return 0;

    *ParentEnd = ChildReads ? Write : Read;
    *ChildEnd = ChildReads ? Read : Write;

    SetHandleInformation(*ParentEnd, HANDLE_FLAG_INHERIT, 0); //The parent's end must not be inherited

    return 1;
}

//A command run, shared by run() (blocking) and spawn() / collect() / cancel() (in the background)
typedef struct
{
    //Input
    char * Command;
    char * Directory;
    char * Input;
    int HasLimit;
    double Limit;           //Elapsed time limit (ms)
    int HasMemoryLimit;
    double MemoryLimit;     //Memory limit per process (bytes)
    int HasCpuLimit;
    double CpuLimit;        //CPU time limit (ms)
    volatile LONG Cancel;   //Set by cancel()

    //Output
    const char * Error;     //Not NULL if the command could not be started
    char * Stdout;
    char * Stderr;
    DWORD ExitCode;
    int TimedOut;
    int MemoryExceeded;
    int Cancelled;
    double PeakMemory;
    double CpuMilliseconds;

    volatile LONG Done;
} RunTask;

static char * CopyText(const char * Text)
{
    if (!Text)
        return NULL;

    const size_t Length = strlen(Text);
    char * Copy = malloc(Length + 1);
    memcpy(Copy, Text, Length + 1);

    return Copy;
}

static double JobCpuMilliseconds(const HANDLE Job)
{
    JOBOBJECT_BASIC_ACCOUNTING_INFORMATION Accounting = {0};

    if (Job && QueryInformationJobObject(Job, JobObjectBasicAccountingInformation, &Accounting, sizeof(Accounting), NULL))
        return (double)(Accounting.TotalUserTime.QuadPart + Accounting.TotalKernelTime.QuadPart) / 10000.0;

    return 0;
}

static void RunCore(RunTask * Task)
{
    HANDLE StdinParent, StdinChild, StdoutParent, StdoutChild, StderrParent, StderrChild;

    if (!CreateChildPipe(&StdinParent, &StdinChild, 1)
        || !CreateChildPipe(&StdoutParent, &StdoutChild, 0)
        || !CreateChildPipe(&StderrParent, &StderrChild, 0))
    {
        Task->Error = "run: can not create pipes.";
        return;
    }

    const size_t CommandLength = strlen(Task->Command) + 32;
    char * CommandLine = malloc(CommandLength);
    snprintf(CommandLine, CommandLength, "cmd.exe /S /C \"%s\"", Task->Command);

    STARTUPINFOA StartupInfo = {0};
    StartupInfo.cb = sizeof(StartupInfo);
    StartupInfo.dwFlags = STARTF_USESTDHANDLES;
    StartupInfo.hStdInput = StdinChild;
    StartupInfo.hStdOutput = StdoutChild;
    StartupInfo.hStdError = StderrChild;

    PROCESS_INFORMATION ProcessInfo = {0};

    //Child processes inherit the error mode: suppress the system "application failed to start" and crash dialogs, which would otherwise block until the timeout
    const UINT PreviousErrorMode = SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX | SEM_NOOPENFILEERRORBOX);

    const BOOL Created = CreateProcessA(
        NULL,
        CommandLine,
        NULL,
        NULL,
        TRUE,
        CREATE_SUSPENDED | CREATE_NO_WINDOW,
        NULL,
        Task->Directory,
        &StartupInfo,
        &ProcessInfo
        );

    free(CommandLine);
    SetErrorMode(PreviousErrorMode);

    //The child's pipe ends now belong to the child; close them here, or the reading side would never see EOF
    CloseHandle(StdinChild);
    CloseHandle(StdoutChild);
    CloseHandle(StderrChild);

    if (!Created)
    {
        CloseHandle(StdinParent);
        CloseHandle(StdoutParent);
        CloseHandle(StderrParent);

        Task->Error = "run: can not start the command (check the directory).";
        return;
    }

    //Manage the whole process tree with a Job so that processes started by cmd are terminated on timeout or exit
    HANDLE Job = CreateJobObjectA(NULL, NULL);
    HANDLE JobPort = NULL;

    if (Job)
    {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION JobLimit = {0};
        JobLimit.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | JOB_OBJECT_LIMIT_DIE_ON_UNHANDLED_EXCEPTION;

        if (Task->HasMemoryLimit)
        {
            JobLimit.BasicLimitInformation.LimitFlags |= JOB_OBJECT_LIMIT_PROCESS_MEMORY;
            JobLimit.ProcessMemoryLimit = (SIZE_T)Task->MemoryLimit;

            //Use a completion port to learn when a process reaches the memory limit
            JobPort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, 0, 1);

            if (JobPort)
            {
                JOBOBJECT_ASSOCIATE_COMPLETION_PORT Association = {.CompletionKey = Job, .CompletionPort = JobPort};
                SetInformationJobObject(Job, JobObjectAssociateCompletionPortInformation, &Association, sizeof(Association));
            }
        }

        SetInformationJobObject(Job, JobObjectExtendedLimitInformation, &JobLimit, sizeof(JobLimit));
        AssignProcessToJobObject(Job, ProcessInfo.hProcess);
    }

    PipeBuffer StdoutBuffer = {.Handle = StdoutParent};
    PipeBuffer StderrBuffer = {.Handle = StderrParent};
    PipeInput StdinData = {.Handle = StdinParent, .Text = Task->Input};

    HANDLE Threads[3] = {
        CreateThread(NULL, 0, ReadPipeThread, &StdoutBuffer, 0, NULL),
        CreateThread(NULL, 0, ReadPipeThread, &StderrBuffer, 0, NULL),
        CreateThread(NULL, 0, WritePipeThread, &StdinData, 0, NULL),
    };

    ResumeThread(ProcessInfo.hThread);

    //Wait in short steps so that the elapsed time limit, the CPU time limit and cancellation are all noticed promptly.
    //A program that simply runs forever is stopped as soon as it has used its CPU time instead of waiting for the elapsed limit.
    const ULONGLONG Started = GetTickCount64();
    int Stop = 0;

    while (WaitForSingleObject(ProcessInfo.hProcess, 50) == WAIT_TIMEOUT)
    {
        if (Task->Cancel)
        {
            Task->Cancelled = 1;
            Stop = 1;
        }else if (Task->HasLimit && (double)(GetTickCount64() - Started) >= Task->Limit)
        {
            Task->TimedOut = 1;
            Stop = 1;
        }else if (Task->HasCpuLimit && JobCpuMilliseconds(Job) > Task->CpuLimit)
        {
            Task->TimedOut = 1;
            Stop = 1;
        }

        if (Stop)
        {
            if (Job)
                TerminateJobObject(Job, 1);
            else
                TerminateProcess(ProcessInfo.hProcess, 1);

            WaitForSingleObject(ProcessInfo.hProcess, INFINITE);
            break;
        }
    }

    GetExitCodeProcess(ProcessInfo.hProcess, &Task->ExitCode);

    if (Job)
    {
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION Usage = {0};

        if (QueryInformationJobObject(Job, JobObjectExtendedLimitInformation, &Usage, sizeof(Usage), NULL))
        {
            Task->PeakMemory = (double)Usage.PeakProcessMemoryUsed;

            if (Task->HasMemoryLimit && Task->PeakMemory >= Task->MemoryLimit)
                Task->MemoryExceeded = 1;

            //The program could not obtain enough memory while loading (e.g. an oversized global array)
            if (Task->HasMemoryLimit && (Task->ExitCode == 0xC0000017 || Task->ExitCode == 0xC000012D))
                Task->MemoryExceeded = 1;
        }

        Task->CpuMilliseconds = JobCpuMilliseconds(Job);
    }

    if (JobPort)
    {
        DWORD Message;
        ULONG_PTR Key;
        LPOVERLAPPED Overlapped;

        while (GetQueuedCompletionStatus(JobPort, &Message, &Key, &Overlapped, 0))
            if (Message == JOB_OBJECT_MSG_PROCESS_MEMORY_LIMIT || Message == JOB_OBJECT_MSG_JOB_MEMORY_LIMIT)
                Task->MemoryExceeded = 1;
    }

    if (Job) //Terminate any child processes still running in the background and holding the pipes
        TerminateJobObject(Job, 1);

    WaitForMultipleObjects(3, Threads, TRUE, INFINITE);

    for (int Index = 0; Index < 3; Index++)
        CloseHandle(Threads[Index]);

    CloseHandle(StdoutParent);
    CloseHandle(StderrParent);
    CloseHandle(ProcessInfo.hThread);
    CloseHandle(ProcessInfo.hProcess);

    if (Job)
        CloseHandle(Job);

    if (JobPort)
        CloseHandle(JobPort);

    Task->Stdout = TakeOutput(&StdoutBuffer);
    Task->Stderr = TakeOutput(&StderrBuffer);

    free(StdoutBuffer.Text);
    free(StderrBuffer.Text);
}

//Reads the arguments shared by run() and spawn(): command, directory, stdin, time limit, memory limit, CPU time limit
static const char * PrepareTask(const ExternalLibraryRequestObj Request, RunTask * Task)
{
    const ValueObj * Command = Argument(Request, 0);
    const ValueObj * Directory = Argument(Request, 1);
    const ValueObj * Input = Argument(Request, 2);
    const ValueObj * Limit = Argument(Request, 3);
    const ValueObj * MemoryLimit = Argument(Request, 4);
    const ValueObj * CpuLimit = Argument(Request, 5);

    if (Command->ValueType != VALUE_STRING_TYPE
        || (Directory->ValueType && Directory->ValueType != VALUE_STRING_TYPE)
        || (Input->ValueType && Input->ValueType != VALUE_STRING_TYPE)
        || (Limit->ValueType && (Limit->ValueType != VALUE_NUMBER_TYPE || Limit->Number < 0))
        || (MemoryLimit->ValueType && (MemoryLimit->ValueType != VALUE_NUMBER_TYPE || MemoryLimit->Number < 1))
        || (CpuLimit->ValueType && (CpuLimit->ValueType != VALUE_NUMBER_TYPE || CpuLimit->Number < 0)))
        return "run(command, directory, stdin, limit, memory, cpu): command should be a string; directory and stdin should be strings or null; limit (ms), memory (bytes) and cpu (ms) should be numbers or null.";

    *Task = (RunTask){
        .Command = CopyText(Command->String),
        .Directory = Directory->ValueType ? CopyText(Directory->String) : NULL,
        .Input = Input->ValueType ? CopyText(Input->String) : NULL,
        .HasLimit = Limit->ValueType != 0,
        .Limit = Limit->ValueType ? Limit->Number : 0,
        .HasMemoryLimit = MemoryLimit->ValueType != 0,
        .MemoryLimit = MemoryLimit->ValueType ? MemoryLimit->Number : 0,
        .HasCpuLimit = CpuLimit->ValueType != 0,
        .CpuLimit = CpuLimit->ValueType ? CpuLimit->Number : 0,
    };

    return NULL;
}

static void FreeTaskInput(RunTask * Task)
{
    free(Task->Command);
    free(Task->Directory);
    free(Task->Input);
    Task->Command = Task->Directory = Task->Input = NULL;
}

//Writes the seven results of a finished task, starting at Values[0]
static void TaskResults(const RunTask * Task, ValueObj * Values)
{
    Values[0] = StringValue(Task->Stdout);
    Values[1] = (ValueObj){.ValueType = VALUE_NUMBER_TYPE, .Number = (Task->TimedOut || Task->Cancelled) ? -1 : (double)Task->ExitCode};
    Values[2] = StringValue(Task->Stderr);
    Values[3] = (ValueObj){.ValueType = VALUE_DB_TYPE, .db = (char)Task->TimedOut};
    Values[4] = (ValueObj){.ValueType = VALUE_DB_TYPE, .db = (char)Task->MemoryExceeded};
    Values[5] = (ValueObj){.ValueType = VALUE_NUMBER_TYPE, .Number = Task->PeakMemory};
    Values[6] = (ValueObj){.ValueType = VALUE_NUMBER_TYPE, .Number = Task->CpuMilliseconds};
}

EXPORT ExternalLibraryRespondObj run(const ExternalLibraryRequestObj Request)
{
    RunTask Task;
    const char * Problem = PrepareTask(Request, &Task);

    if (Problem)
        return Fail(Request, (char *)Problem);

    RunCore(&Task);
    FreeTaskInput(&Task);

    if (Task.Error)
        return Fail(Request, (char *)Task.Error);

    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;
    Result.ValueCarrier.CarrierLen = 7;
    Result.ValueCarrier.Carrier = NewValues(7);
    TaskResults(&Task, Result.ValueCarrier.Carrier);

    return Result;
}

//////////////////////////////////////// spawn / collect / cancel ////////////////////////////////////////
// spawn(same arguments as run) -> task id
//   Starts the command in the background and returns immediately, so that a window can stay responsive.
// collect(task id) -> "running"
//                  -> "done", standard output, exit code, standard error, timed out, memory limit exceeded, peak memory, CPU time, cancelled
//                  -> "error", message
//   Once "done" or "error" has been returned, the task id is released.
// cancel(task id)
//   Terminates the command (including its whole process tree); collect() then reports cancelled = true.

static RunTask ** Tasks = NULL;
static unsigned TaskCount = 0;

static DWORD WINAPI RunTaskThread(LPVOID Parameter)
{
    RunTask * Task = Parameter;

    RunCore(Task);
    FreeTaskInput(Task);
    InterlockedExchange(&Task->Done, 1);

    return 0;
}

static RunTask * FindTask(const ExternalLibraryRequestObj Request, unsigned * Slot)
{
    const ValueObj * Id = Argument(Request, 0);

    if (Id->ValueType != VALUE_NUMBER_TYPE || Id->Number < 1 || Id->Number > TaskCount)
        return NULL;

    *Slot = (unsigned)Id->Number - 1;

    return Tasks[*Slot];
}

EXPORT ExternalLibraryRespondObj spawn(const ExternalLibraryRequestObj Request)
{
    RunTask * Task = calloc(1, sizeof(RunTask));
    const char * Problem = PrepareTask(Request, Task);

    if (Problem)
    {
        free(Task);
        return Fail(Request, (char *)Problem);
    }

    unsigned Slot = 0;

    while (Slot < TaskCount && Tasks[Slot])
        Slot++;

    if (Slot == TaskCount)
    {
        Tasks = realloc(Tasks, sizeof(RunTask *) * (TaskCount + 1));
        TaskCount++;
    }

    Tasks[Slot] = Task;

    HANDLE Thread = CreateThread(NULL, 0, RunTaskThread, Task, 0, NULL);

    if (!Thread)
    {
        Tasks[Slot] = NULL;
        FreeTaskInput(Task);
        free(Task);
        return Fail(Request, "spawn: can not create a thread.");
    }

    CloseHandle(Thread);

    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;
    Result.ValueCarrier.CarrierLen = 1;
    Result.ValueCarrier.Carrier = NewValues(1);
    Result.ValueCarrier.Carrier[0] = (ValueObj){.ValueType = VALUE_NUMBER_TYPE, .Number = Slot + 1};

    return Result;
}

EXPORT ExternalLibraryRespondObj collect(const ExternalLibraryRequestObj Request)
{
    unsigned Slot;
    RunTask * Task = FindTask(Request, &Slot);

    if (!Task)
        return Fail(Request, "collect(task id): unknown task id.");

    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;

    if (!Task->Done)
    {
        Result.ValueCarrier.CarrierLen = 1;
        Result.ValueCarrier.Carrier = NewValues(1);
        Result.ValueCarrier.Carrier[0] = StringValue("running");
        return Result;
    }

    if (Task->Error)
    {
        Result.ValueCarrier.CarrierLen = 2;
        Result.ValueCarrier.Carrier = NewValues(2);
        Result.ValueCarrier.Carrier[0] = StringValue("error");
        Result.ValueCarrier.Carrier[1] = StringValue((char *)Task->Error);
    }else
    {
        Result.ValueCarrier.CarrierLen = 9;
        Result.ValueCarrier.Carrier = NewValues(9);
        Result.ValueCarrier.Carrier[0] = StringValue("done");
        TaskResults(Task, Result.ValueCarrier.Carrier + 1);
        Result.ValueCarrier.Carrier[8] = (ValueObj){.ValueType = VALUE_DB_TYPE, .db = (char)Task->Cancelled};
    }

    //The output strings now belong to the returned values; only the task itself is released
    Tasks[Slot] = NULL;
    free(Task);

    return Result;
}

EXPORT ExternalLibraryRespondObj cancel(const ExternalLibraryRequestObj Request)
{
    unsigned Slot;
    RunTask * Task = FindTask(Request, &Slot);

    if (Task)
        InterlockedExchange(&Task->Cancel, 1);

    ExternalLibraryRespondObj Result = {0};
    Result.Event = Request.EventTemplate;

    return Result;
}
