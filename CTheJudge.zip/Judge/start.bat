@echo off
rem CTheJudge launcher (runs mione\editor.mio with the Mione interpreter)
cd /d "%~dp0"
start "CTheJudge" "%~dp0mione\Mione.exe" "%~dp0mione\editor.mio"
