param([string]$ProblemUrl)
$ErrorActionPreference = 'Stop'
$MinimumVersion = [version]'0.1.1'
$VersionUri = [uri]'https://source.hxx.lol/mione/version.json'

function Update-ProcessPath {
    $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + $env:Path
}

function Get-MionePathCandidates {
    # where.exe is requested explicitly; ignore implicit current-directory hits.
    $previousPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $paths = @(& "$env:SystemRoot\System32\where.exe" Mione 2>$null)
        $whereCode = $LASTEXITCODE
    } finally { $ErrorActionPreference = $previousPreference }
    if ($whereCode -ne 0) { return }
    $directories = @($env:Path -split ';' | ForEach-Object {
        $entry = [Environment]::ExpandEnvironmentVariables($_.Trim().Trim('"'))
        if ($entry -and [IO.Path]::IsPathRooted($entry)) {
            [IO.Path]::GetFullPath($entry).TrimEnd('\')
        }
    })
    foreach ($path in $paths) {
        if ([IO.Path]::GetExtension($path) -ieq '.exe' -and
            $directories -icontains [IO.Path]::GetDirectoryName($path).TrimEnd('\')) {
            $path
        }
    }
}

function Get-RegisteredMioneCandidates {
    # WiX writes InstallDir for default and custom locations, in either scope.
    foreach ($key in @('HKCU:\Software\Mione', 'HKLM:\Software\Mione',
        'HKCU:\Software\WOW6432Node\Mione', 'HKLM:\Software\WOW6432Node\Mione')) {
        $record = Get-ItemProperty -LiteralPath $key -ErrorAction SilentlyContinue
        if ($record.InstallDir) {
            $candidate = Join-Path $record.InstallDir 'Mione.exe'
            if (Test-Path -LiteralPath $candidate -PathType Leaf) { $candidate }
        }
    }
}

function Find-Mione {
    # Inspect every PATH match before falling back to the MSI installation record.
    $candidates = @(@(Get-MionePathCandidates) + @(Get-RegisteredMioneCandidates) | Select-Object -Unique)
    foreach ($candidate in $candidates) {
        $version = Get-MioneVersion $candidate
        if ($version -and $version -ge $MinimumVersion) { return $candidate }
        Write-Host "Skipping Mione at ${candidate}: version '$version' (requires $MinimumVersion)."
    }
}

function Test-MsiInstalled([string]$Path) {
    $installer = New-Object -ComObject WindowsInstaller.Installer
    $database = $null; $view = $null; $record = $null
    try {
        $database = $installer.OpenDatabase($Path, 0)
        $view = $database.OpenView("SELECT Value FROM Property WHERE Property = 'ProductCode'")
        [void]$view.Execute()
        $record = $view.Fetch()
        if (-not $record) { throw 'The MSI does not contain a ProductCode.' }
        return ($installer.ProductState($record.StringData(1)) -eq 5)
    } finally {
        if ($view) { [void]$view.Close() }
        foreach ($object in @($record, $view, $database, $installer)) {
            if ($object) { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($object) }
        }
    }
}

function Get-MioneVersion([string]$Executable) {
    if (-not $Executable) { return }
    $info = New-Object System.Diagnostics.ProcessStartInfo
    $info.FileName = $Executable
    $info.Arguments = '--version'
    $info.UseShellExecute = $false
    $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $info
    try {
        if (-not $process.Start()) { return }
        if (-not $process.WaitForExit(10000)) {
            $process.Kill()
            return
        }
        $output = $process.StandardOutput.ReadToEnd().Trim()
        if ($process.ExitCode -eq 0 -and $output -match '^Mione\s+(\d+\.\d+\.\d+(?:\.\d+)?)$') {
            return [version]$Matches[1]
        }
    } catch {
        Write-Host "Could not read Mione version: $($_.Exception.Message)"
    } finally {
        $process.Dispose()
    }
}

function ConvertFrom-ReleaseManifest([string]$Text, [uri]$Source) {
    try { $data = $Text | ConvertFrom-Json } catch {
        throw 'version.json must contain valid JSON with latest and versions fields.'
    }
    $versionText = $data.latest
    if (-not ($versionText -is [string]) -or $versionText -notmatch '^\d+\.\d+\.\d+(?:\.\d+)?$') {
        throw 'Invalid or missing latest release version in version.json.'
    }
    $version = [version]$versionText
    if ($version -lt $MinimumVersion) { throw "The published release $version is older than required $MinimumVersion." }
    $download = $null
    if ($data.versions) {
        $entry = $data.versions.PSObject.Properties[$versionText]
        if ($entry) { $download = $entry.Value }
    }
    if (-not ($download -is [string]) -or -not $download) {
        throw "Missing MSI URL for latest release $versionText in version.json versions."
    }
    $uri = New-Object System.Uri($Source, $download)
    if ($uri.Scheme -ne 'https' -or $uri.AbsolutePath -notmatch '\.msi$') { throw 'The installer URL must be an HTTPS MSI URL.' }
    return [pscustomobject]@{ Version = $version; Uri = $uri }
}

function Install-LatestMione {
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
    Write-Host "Checking latest release: $VersionUri"
    $response = Invoke-WebRequest -Uri $VersionUri -UseBasicParsing -TimeoutSec 30
    $release = ConvertFrom-ReleaseManifest ([string]$response.Content) $VersionUri
    $downloadDirectory = Join-Path ([IO.Path]::GetTempPath()) ('CTheJudge-Mione-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $downloadDirectory | Out-Null
    $msi = Join-Path $downloadDirectory ("Mione-$($release.Version)-x64.msi")
    try {
        Write-Host "Downloading Mione $($release.Version): $($release.Uri)"
        Invoke-WebRequest -Uri $release.Uri -UseBasicParsing -TimeoutSec 300 -OutFile $msi
        # MSI files are OLE compound documents. Reject HTML/error pages before opening setup.
        $stream = [IO.File]::OpenRead($msi)
        try {
            $header = New-Object byte[] 8
            $length = $stream.Read($header, 0, 8)
        } finally { $stream.Dispose() }
        if ($length -ne 8 -or [BitConverter]::ToString($header) -ne 'D0-CF-11-E0-A1-B1-1A-E1') {
            throw 'The downloaded file is not an MSI package.'
        }
        Write-Host 'Complete Mione setup to continue.'
        $installArguments = @('/i', ('"' + $msi + '"'), 'REINSTALLMODE=amus', '/l*v', ('"' + $env:CTHEJUDGE_INSTALL_LOG + '"'))
        if (Test-MsiInstalled $msi) { $installArguments += 'REINSTALL=ALL' }
        $install = Start-Process -FilePath "$env:SystemRoot\System32\msiexec.exe" -ArgumentList $installArguments -Wait -PassThru
        if ($install.ExitCode -notin @(0, 1641, 3010)) { throw "Installation failed or was cancelled (exit $($install.ExitCode))." }
        Write-Host 'Setup completed. Restarting start.bat to check PATH and version again...'
    } finally {
        if (Test-Path -LiteralPath $msi) { Remove-Item -LiteralPath $msi -Force }
        if (Test-Path -LiteralPath $downloadDirectory) { Remove-Item -LiteralPath $downloadDirectory -Force }
    }
}

function Invoke-Judge {
    $env:NoDefaultCurrentDirectoryInExePath = '1'
    # New setup writes persistent PATH, while the BAT parent retains the old copy.
    Update-ProcessPath
    $mione = Find-Mione
    $version = Get-MioneVersion $mione
    if (-not $version -or $version -lt $MinimumVersion) {
        if ($env:CTHEJUDGE_AFTER_INSTALL -eq '1') {
            throw "Setup exited successfully, but no Mione >= $MinimumVersion was found in PATH or the MSI installation record. Installer log: $env:CTHEJUDGE_INSTALL_LOG"
        }
        Write-Host 'Mione >= 0.1.1 is required. Opening the latest installer.'
        if (-not $env:CTHEJUDGE_INSTALL_LOG) {
            $env:CTHEJUDGE_INSTALL_LOG = Join-Path ([IO.Path]::GetTempPath()) ('CTheJudge-Mione-' + [guid]::NewGuid().ToString('N') + '.log')
        }
        Install-LatestMione
        return 10 # start.bat reruns itself once after successful setup.
    }
    Write-Host "Using Mione $version from PATH: $mione"
    # Pin the interpreter selected above for cmd.exe-based download/judge children too.
    $env:Path = [IO.Path]::GetDirectoryName($mione) + ';' + $env:Path
    return (Start-JudgeEditor $mione)
}

function Start-JudgeEditor([string]$mione) {
    Set-Location -LiteralPath $PSScriptRoot
    $scriptArguments = @((Join-Path $PSScriptRoot 'mione\editor.mio'))
    if ($ProblemUrl) { $scriptArguments += $ProblemUrl }
    & $mione @scriptArguments | Out-Host
    # Keep the application's exit code distinct from the launcher's retry signal.
    if ($LASTEXITCODE -eq 0) { return 0 }
    return 1
}

try { exit (Invoke-Judge) } catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
