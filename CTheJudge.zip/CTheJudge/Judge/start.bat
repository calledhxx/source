@echo off
setlocal
set "CTHEJUDGE_AFTER_INSTALL="
set "CTHEJUDGE_INSTALL_LOG=%TEMP%\CTheJudge-Mione-%RANDOM%-%RANDOM%.log"
:check
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-Judge.ps1" %*
set "judgeExit=%errorlevel%"
if "%judgeExit%"=="10" (
    set "CTHEJUDGE_AFTER_INSTALL=1"
    goto check
)
if not "%judgeExit%"=="0" pause
exit /b %judgeExit%
